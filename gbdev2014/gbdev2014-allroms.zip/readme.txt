Entries in the 2014 GB dev compo. Visit the link below to vote or discuss the entries:

http://gg8.se/gbvote or http://gbdev.gg8.se/forums/viewforum.php?id=9