-Name: Back to Color
-Author: AntonioND
-Forum user: AntonioND (who'd have said it...) http://gbdev.gg8.se/forums/profile.php?id=477
-Description:
Here it is my first GBC demo. I started it like four years ago, but stopped after doing 3 scenes (not great, that's why I stopped). I�ve coded the rest in just a few weeks, in fact I started doing new effects a few days before the GBDev compo announcement. So... that's it! I hope you like it!

I've coded it, and made the music, the only thing I haven't done is the train screen graphics and the credits graphics. Oh, and it shows a little credits screen in non-color gameboys! If you want to skip some parts, hold up/right/down/left when the demo is loading if you want to skip 1/2/3/4 songs.

I've attached the binary and some screenshots. It works on most emulators (the pentagon thing has a problem with priorities in old versions of VBA, but BGB, Gambatte and VBA-M emulate it correctly) and, of course, real hardware.

And here's a little video for the lazy ones smile
https://www.youtube.com/watch?v=MzfG4sGib_0
===
Source code on GitHub and other things:

https://github.com/AntonioND/back-to-color
http://antoniond_blog.drunkencoders.com/?p=314
https://www.youtube.com/watch?v=eSEsd1OGA74

Download is in the blog, or here:

https://github.com/AntonioND/back-to-color/releases/tag/v1.0

The demo binary should be the same as here.