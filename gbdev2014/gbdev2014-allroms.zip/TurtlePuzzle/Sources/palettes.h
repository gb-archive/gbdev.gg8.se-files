#ifndef PALETTES_H
#define PALETTES_H

#include <gb/gb.h>

extern UWORD turtleTilesPalette[];
extern UWORD turtleSpritesPalette[];

#endif
