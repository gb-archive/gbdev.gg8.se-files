#ifndef LEVELOBJECTS022_H
#define LEVELOBJECTS022_H

extern unsigned char levelObjects022[];
#endif
