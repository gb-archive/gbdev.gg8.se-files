#ifndef LEVEL021_H
#define LEVEL021_H

extern unsigned char level021[];
#endif
