#ifndef LEVELOBJECTS016_H
#define LEVELOBJECTS016_H

extern unsigned char levelObjects016[];
#endif
