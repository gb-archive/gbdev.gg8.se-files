#ifndef LEVELOBJECTS020_H
#define LEVELOBJECTS020_H

extern unsigned char levelObjects020[];
#endif
