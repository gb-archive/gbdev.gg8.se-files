#ifndef LEVEL022_H
#define LEVEL022_H

extern unsigned char level022[];
#endif
