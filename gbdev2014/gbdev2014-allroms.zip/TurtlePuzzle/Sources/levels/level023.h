#ifndef LEVEL023_H
#define LEVEL023_H

extern unsigned char level023[];
#endif
