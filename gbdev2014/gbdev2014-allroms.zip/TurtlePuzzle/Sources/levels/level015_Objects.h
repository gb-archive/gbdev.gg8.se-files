#ifndef LEVELOBJECTS015_H
#define LEVELOBJECTS015_H

extern unsigned char levelObjects015[];
#endif
