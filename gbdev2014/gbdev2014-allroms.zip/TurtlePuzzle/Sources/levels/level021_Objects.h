#ifndef LEVELOBJECTS021_H
#define LEVELOBJECTS021_H

extern unsigned char levelObjects021[];
#endif
