#ifndef LEVELOBJECTS018_H
#define LEVELOBJECTS018_H

extern unsigned char levelObjects018[];
#endif
