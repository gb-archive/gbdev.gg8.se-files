#ifndef LEVEL018_H
#define LEVEL018_H

extern unsigned char level018[];
#endif
