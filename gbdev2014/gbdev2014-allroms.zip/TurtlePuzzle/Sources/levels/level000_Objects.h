#ifndef LEVELOBJECTS000_H
#define LEVELOBJECTS000_H

extern unsigned char levelObjects000[];
#endif
