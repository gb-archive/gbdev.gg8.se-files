#ifndef LEVELOBJECTS023_H
#define LEVELOBJECTS023_H

extern unsigned char levelObjects023[];
#endif
