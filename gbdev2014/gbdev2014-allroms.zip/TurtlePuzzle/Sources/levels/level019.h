#ifndef LEVEL019_H
#define LEVEL019_H

extern unsigned char level019[];
#endif
