#ifndef LEVEL000_H
#define LEVEL000_H

extern unsigned char level000[];
#endif
