#ifndef LEVEL017_H
#define LEVEL017_H

extern unsigned char level017[];
#endif
