#ifndef LEVELOBJECTS017_H
#define LEVELOBJECTS017_H

extern unsigned char levelObjects017[];
#endif
