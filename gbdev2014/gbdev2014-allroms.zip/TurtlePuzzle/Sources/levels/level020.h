#ifndef LEVEL020_H
#define LEVEL020_H

extern unsigned char level020[];
#endif
