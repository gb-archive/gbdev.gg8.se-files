#ifndef LEVELOBJECTS019_H
#define LEVELOBJECTS019_H

extern unsigned char levelObjects019[];
#endif
