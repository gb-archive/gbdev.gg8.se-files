#define black RGB(1, 1, 1)
#define darkgray RGB(10, 10, 10)
#define lightgray RGB(20, 20, 20)
#define white RGB(15, 15, 15)

#define blue RGB(0, 0, 31)
#define darkblue RGB(0, 0, 16)
#define aqua RGB(10, 10, 31)
#define cyan RGB(0, 31, 31)

#define red RGB(31, 0, 0)
#define darkred RGB(16, 0, 0)
#define green RGB(0, 31, 0)
#define darkgreen RGB(0, 16, 0)

#define yellow RGB(31, 31, 0)
#define darkyellow RGB(16, 16, 0)
#define pink RGB(31, 0, 31)
#define purple RGB(20, 0, 16)

#define lightflesh RGB(31, 20, 15)
#define brown RGB(10, 10, 0)
#define orange RGB(31, 16, 0)
#define teal RGB(15, 15,  0)
