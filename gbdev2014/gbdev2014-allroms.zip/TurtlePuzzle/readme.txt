Turtle Puzzle by UraKn0x (Antoine COUY)

This game is an algorithmic game based on Robozzle.
You must program your robot using the given instructions to collect the dots.
The different instructions are : 
-Moving forward
-Turning clockwise or counter-clockwise
-Calling a function
-Painting a cell
The function calls are recursive: once the called function is done, the program
will return where the function was called: this is recursivity. The return stack
at the top of the screen may help you in advanced levels which use recursivity.

In addition to that, you can add conditions to your instructions. The 
instruction will then be executed only if the robot is on a cell with a given
color.

Your robot must not:
-Leave the colored cells.
-Run out of instructions.

Some functions(as SPEED and RUN menus) do not work. 
However, the game is fully playable.

Controls:
Select an instruction with the arrow keys.
With A, you will be able to change it.
Press Start to run your algorithm.
Press B to return to level selection.

Enjoy!