Name of Developer: Jaeden Amero
Forum Name: Patater
Developer's Website: http://www.patater.com/
Project Name: Slider
Description:
Turn it up to eleven, two to the power of eleven that is, with Slider.
Slider is the latest 2048 clone, and this time it's more portable than
ever. Sailing around Thailand's beautiful sunny beaches? No problem!
Slider features very high contrast graphics and looks great on the
Game Boy screen, even in direct sunlight. Low on batteries hiking
around the subarctic Alaskan wilderness? Slider sips juice from the
bounteous bosom of Game Boy; not even your cell phone can play this
game for as long as your Game Boy! Take Slider with you anywhere,
anytime. It's quite a slide.