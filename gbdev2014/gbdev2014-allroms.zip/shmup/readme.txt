<Kresna> Hey Sanqui, just dropping you a link to what I've done for the compo, which isn't a lot tongue
<Kresna> You can fly with the D-Pad and Shoot with B, there's nothing to shoot though, that's all I've done
<Kresna> It also works on hardware