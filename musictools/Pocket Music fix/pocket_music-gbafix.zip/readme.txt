Pocket Music for Gameboy Color refuses to run on GBA. It shows a screen 
similar to when you run the game on a monochrome Gameboy, saying "this game
is intended only for use with a Gameboy Color."

Maybe they decided to do this because the sample playback sounds like crap on
GBA. This patch fixes both those problems. It bypasses the GBA check so you
can ue Pocket Music on GBA, and it uses my "antispike" fix (also seen in LSDj)
to almost completely remove the whine from the sample playback.

Use an IPS patcher to apply the patch to the Pocket Music GBC ROM.

-nitro2k01

http://blog.gg8.se/wordpress/
