carillon-wf.gb 1.0

A wave channel editor for Carillon. Edits the 16 waveforms available to the 
editor. Available through a new menu option in the Carillon menu.

Buttons:

Select       - Return to Carillon main menu.
Start        - Start/stop playing the current waveform. Updates automatically
               to any changes.

Left/Right   - Move cursor left/right in waveform.
A+Up/Down    - Edit sample at cursor.
A+Left/Right - Copy or "draw" the sample at the cursor left/right


B+Up/Down    - Go to next/previous waveform.
B+Select     - Copy current waveform to Carillon's buffer. (Same buffer as
               in Carillon's menu so this corrupts anything in the buffer.)
B+Start      - Paste the clipboard buffer to the current waveform.
B+A          - Clear current waveform. Repeat multiple times to cycle through
               Carillon's default waveforms.
