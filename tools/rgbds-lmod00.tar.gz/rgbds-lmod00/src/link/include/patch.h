#ifndef	PATCH_H
#define	PATCH_H

#include	"types.h"

void	Patch( void );
extern	SLONG	nPC;

#endif
