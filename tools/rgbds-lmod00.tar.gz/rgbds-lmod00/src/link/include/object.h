#ifndef	OBJECT_H
#define	OBJECT_H

extern	void	obj_Readfile( char *tzObjectfile );
extern	void	lib_Readfile( char *tzLibfile );

#endif
