#ifndef	OUTPUT_H
#define	OUTPUT_H

void	out_Setname( char *tzOutputfile );
void	Output( void );

#endif

